<?php
 return array (
  'theme_color' => 'default',
  'background_url' => '',
  'theme_sidebar' => 'light',
  'theme_header' => 'dark',
  'custom_html' => '',
) ;