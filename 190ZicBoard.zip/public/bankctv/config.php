<?php
const CONFIG = [
                    
                    'TOKEN' => "ZicBoard",
                    
                    'GATE' =>[
                        
                        'BANK'=> [
                            
                        ]
                    ]
                ];