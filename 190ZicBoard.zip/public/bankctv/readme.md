B1: tải file thư mục public
B2: tạo thư mục rồi giải nén vào.
B3: di chuyển file Bankctv.php sang thư mục app/payments
B4: vào admin cấu hình thanh toán.