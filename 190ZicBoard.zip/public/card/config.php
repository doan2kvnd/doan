<?php
const CONFIG = [
                    'DOMAINV2B' => "dailysieure.vn", //domain của v2board
                    'TOKEN' => "tokenbatkiapivpnfastvn",//lấy từ api.vpnfast.vn
                    'SIGNATIRE' => "", //lấy từ api.vpnfast.vn
                    'KEYWORD' => "", //nội dung bank atm
                    'IDTELE' => "", // id admin telegram
                    'TOKENBOT' => "", // token bot telegram
                    'GATE' =>[
                        'CARD'=> [
                            'PartnerID' => "", // lấy từ gachthenhanh.net
                            'PartnerKey' => "", // lấy từ gachthenhanh.net
                            'WEBHOOK' => "https://xxxxx/api/v1/guest/payment/notify/Card/FKhexzWK" // lấy trong admin v2board
                        ]
                    ]
                ];