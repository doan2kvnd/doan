<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/components.chunk.css?v=<?php echo e($version); ?>">
    <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/umi.css?v=<?php echo e($version); ?>">
    <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/bopboard.css?v=<?php echo e($version); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    
       
    
    <?php if(file_exists(public_path("/theme/{$theme}/assets/custom.css"))): ?>
        <link rel="stylesheet" href="/theme/<?php echo e($theme); ?>/assets/custom.css?v=<?php echo e($version); ?>">
    <?php endif; ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
    <?php ($colors = [
        'darkblue' => '#3b5998',
        'black' => '#343a40',
        'default' => '#0665d0',
        'green' => '#319795'
    ]); ?>
    <meta name="theme-color" content="<?php echo e($colors[$theme_config['theme_color']]); ?>">

    <title><?php echo e($domainTitle); ?></title>
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,400i,600,700"> -->
    <script>
        window.domainTitle = <?php echo json_encode($domainTitle, 15, 512) ?>;
    </script>
    <script>window.routerBase = "/";</script>
    <script>
        window.settings = {
            title: '<?php echo e($domainTitle); ?>',
            
            assets_path: '/theme/<?php echo e($theme); ?>/assets',
            theme: {
                sidebar: '<?php echo e($theme_config['theme_sidebar']); ?>',
                header: '<?php echo e($theme_config['theme_header']); ?>',
                color: '<?php echo e($theme_config['theme_color']); ?>',
            },
            version: 'Leowboard',
            background_url: '<?php echo e($theme_config['background_url']); ?>',
            description: '<?php echo e($DTMota); ?>',
            i18n: [
                'zh-CN',
                'en-US',
                'ja-JP',
                'vi-VN',
                'ko-KR',
                'zh-TW',
                'fa-IR'
            ],
            logo: '<?php echo e($DTLogo); ?>'
        }
    </script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/zh-CN.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/zh-TW.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/en-US.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/ja-JP.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/vi-VN.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/ko-KR.js?v=<?php echo e($version); ?>"></script>
    <script src="/theme/<?php echo e($theme); ?>/assets/i18n/fa-IR.js?v=<?php echo e($version); ?>"></script>
</head>

<body>
<div id="root"></div>
<?php echo $theme_config['custom_html']; ?>

<script src="/theme/<?php echo e($theme); ?>/assets/vendors.async.js?v=<?php echo e($version); ?>"></script>
<script src="/theme/<?php echo e($theme); ?>/assets/bopboard.js?v=<?php echo e($version); ?>"></script>
<script src="/theme/<?php echo e($theme); ?>/assets/components.async.js?v=<?php echo e($version); ?>"></script>
<script src="/theme/<?php echo e($theme); ?>/assets/umi.js?v=<?php echo e($version); ?>"></script>

    <script src="https://apple.xn--ss-8ja.vn/static/js/tabler.min.js"></script>
    <script src="https://apple.xn--ss-8ja.vn/static/js/sweetalert2.all.min.js"></script>
    
    <script src="https://apple.xn--ss-8ja.vn/static/js/clipboard.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel="stylesheet">

<?php if(file_exists(public_path("/theme/{$theme}/assets/custom.js"))): ?>
    <script src="/theme/<?php echo e($theme); ?>/assets/custom.js?v=<?php echo e($version); ?>"></script>
<?php endif; ?>

<script>
    var clipboard = new ClipboardJS('.btn');

    function alert_success() {
        Swal.fire({
            icon: 'success',
            title: 'Thông báo',
            text: 'Sao chép thành công',
            timer: 1000,
            timerProgressBar: true
        });
    }

    function updateCardStyle() {
      var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
      var styleElement = document.createElement('style');

      if (width < 1040) {
        styleElement.innerHTML = '.card { margin-top: 1rem; }';
      } else {
        styleElement.innerHTML = '.card { margin-top: 1rem; margin-left: 35%; width: 30%; }';
      }

      var oldStyleElement = document.getElementById('card-style');
      if (oldStyleElement) {
        oldStyleElement.parentNode.removeChild(oldStyleElement);
      }

      styleElement.id = 'card-style';
      document.getElementsByTagName('head')[0].appendChild(styleElement);
    }
    </script>


</body>

 </html>
 <SCRIPT LANGUAGE="JavaScript" type="33feace03574fff78a06825f-text/javascript">
    <!--
    //Disable right click script III- By Renigade (renigade@mediaone.net)
    //For full source code, visit http://www.dynamicdrive.com
    var message = "KhánhĐzai";
    ///////////////////////////////////
    function clickIE() {
        if (document.all) {
            (message);
            return false;
        }
    }

    function clickNS(e) {
        if (document.layers || (document.getElementById && !document.all)) {
            if (e.which == 2 || e.which == 3) {
                (message);
                return false;
            }
        }
    }
    if (document.layers) {
        document.captureEvents(Event.MOUSEDOWN);
        document.onmousedown = clickNS;
    } else {
        document.onmouseup = clickNS;
        document.oncontextmenu = clickIE;
    }
    document.oncontextmenu = new Function("return false")
        // -->
</SCRIPT>
</html>
<?php /**PATH /www/wwwroot/dailysieure.vn/public/theme/default/dashboard.blade.php ENDPATH**/ ?>